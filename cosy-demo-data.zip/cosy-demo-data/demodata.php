<?php

function la_cosy_get_demo_array($dir_url, $dir_path){

    $demo = array(
        'main-fashion-01' => array(
            'title' 		=> 'Shop Modern 01',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'main-01.zip',
            'content' 		=> $dir_path . 'cosy-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'fashion-01.json',
            'preview'		=> $dir_url  . 'main-01.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Main Fashion 01',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'fashion-01',
            'demo_url'      => 'http://cosy.la-studioweb.com/'
        ),
        'main-fashion-02' => array(
            'title' 		=> 'Shop Modern 02',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'main-02.zip',
            'content' 		=> $dir_path . 'cosy-content.xml',
            'widget' 		=> $dir_path . 'widget-default.json',
            'option' 		=> $dir_path . 'fashion-01.json',
            'preview'		=> $dir_url  . 'main-02.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Main Fashion 02',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'fashion-02',
            'demo_url'      => 'http://cosy.la-studioweb.com/main-fashion-02'
        ),
        'main-fashion-03' => array(
            'title' 		=> 'Shop Minimal',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'main-03.zip',
            'content' 		=> $dir_path . 'cosy-content.xml',
            'widget' 		=> $dir_path . 'widget-03.json',
            'option' 		=> $dir_path . 'fashion-03.json',
            'preview'		=> $dir_url  . 'main-03.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Main Fashion 03',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'fashion-03',
            'demo_url'      => 'http://cosy.la-studioweb.com/main-fashion-03'
        ),
        'main-minimal-04' => array(
            'title' 		=> 'Furniture & Accessories',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'main-04.zip',
            'content' 		=> $dir_path . 'cosy-content.xml',
            'widget' 		=> $dir_path . 'widget-04.json',
            'option' 		=> $dir_path . 'fashion-04.json',
            'preview'		=> $dir_url  . 'main-04.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Main Minimal 04',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'fashion-04',
            'demo_url'      => 'http://cosy.la-studioweb.com/main-minimal-04'
        ),
        'main-bike' => array(
            'title' 		=> 'Mountain Bikes',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'main-bike.zip',
            'content' 		=> $dir_path . 'cosy-content.xml',
            'widget' 		=> $dir_path . 'widget-05.json',
            'option' 		=> $dir_path . 'bike-01.json',
            'preview'		=> $dir_url  . 'main-05.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Main Bike',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'bike-01',
            'demo_url'      => 'http://cosy.la-studioweb.com/main-bike'
        ),
        'main-sport' => array(
            'title' 		=> 'Shop Sport',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'main-sport.zip',
            'content' 		=> $dir_path . 'cosy-content.xml',
            'widget' 		=> $dir_path . 'widget-06.json',
            'option' 		=> $dir_path . 'sport-01.json',
            'preview'		=> $dir_url  . 'main-06.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation',
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Main Sport',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'sport-01',
            'demo_url'      => 'http://cosy.la-studioweb.com/main-sport'
        ),
        'main-organic' => array(
            'title' 		=> 'Organic Store',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'main-organic.zip',
            'content' 		=> $dir_path . 'cosy-content.xml',
            'widget' 		=> $dir_path . 'widget-07.json',
            'option' 		=> $dir_path . 'organic-01.json',
            'preview'		=> $dir_url  . 'main-07.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Main Organic',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'organic-01',
            'demo_url'      => 'http://cosy.la-studioweb.com/main-organic'
        ),
        'main-flower' => array(
            'title' 		=> 'Flower Store',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'main-flower.zip',
            'content' 		=> $dir_path . 'cosy-content.xml',
            'widget' 		=> $dir_path . 'widget-08.json',
            'option' 		=> $dir_path . 'flower-01.json',
            'preview'		=> $dir_url  . 'main-08.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Main Flower',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'flower-01',
            'demo_url'      => 'http://cosy.la-studioweb.com/main-flower'
        ),
        'main-electronic' => array(
            'title' 		=> 'Tech Store',
            'category'      => 'demo',
            'slider' 		=> $dir_path . 'main-electronic.zip',
            'content' 		=> $dir_path . 'cosy-content.xml',
            'widget' 		=> $dir_path . 'widget-09.json',
            'option' 		=> $dir_path . 'electronic.json',
            'preview'		=> $dir_url  . 'main-09.jpg',
            'menu-locations'=> array(
                'main-nav'      => 'Primary Navigation'
            ),
            'pages'			=> array(
                'page_on_front' 	=> 'Main Electronic',
                'page_for_posts' 	=> 'Blog'
            ),
            'demo_preset'   => 'electronic-01',
            'demo_url'      => 'http://cosy.la-studioweb.com/main-electronic'
        ),
        'o-single-product-1' => array(
            'title' 		=> 'Single Product 01',
            'category'      => 'cat1',
            'preview'		=> $dir_url  . 'single-product-01.jpg',
            'demo_url'      => 'http://cosy.la-studioweb.com/product/floral-print-dress/?la_preset=product1'
        ),
        'o-single-product-2' => array(
            'title' 		=> 'Single Product 02',
            'category'      => 'cat1',
            'preview'		=> $dir_url  . 'single-product-02.jpg',
            'demo_url'      => 'http://cosy.la-studioweb.com/product/floral-print-dress/?la_preset=product2'
        ),
        'o-single-product-3' => array(
            'title' 		=> 'Single Product 03',
            'category'      => 'cat1',
            'preview'		=> $dir_url  . 'single-product-03.jpg',
            'demo_url'      => 'http://cosy.la-studioweb.com/product/floral-print-dress/?la_preset=product3'
        ),
        'o-shop-fw1' => array(
            'title' 		=> 'Shop FullWidth',
            'category'      => 'cat1',
            'preview'		=> $dir_url  . 'shop-fw.jpg',
            'demo_url'      => 'http://cosy.la-studioweb.com/shop/?la_preset=shop-fullwidth'
        ),
        'o-shop-fw2' => array(
            'title' 		=> 'Shop FullWidth2',
            'category'      => 'cat1',
            'preview'		=> $dir_url  . 'shop-fw2.jpg',
            'demo_url'      => 'http://cosy.la-studioweb.com/shop/?la_preset=shop-fullwidth2'
        ),
        'o-shop-sb' => array(
            'title' 		=> 'Shop Sidebar',
            'category'      => 'cat1',
            'preview'		=> $dir_url  . 'shop-sb.jpg',
            'demo_url'      => 'http://cosy.la-studioweb.com/shop/?la_preset=shop-sidebar'
        ),
        'o-shop-cll' => array(
            'title' 		=> 'Shop Collections',
            'category'      => 'cat1',
            'preview'		=> $dir_url  . 'shop-cll.jpg',
            'demo_url'      => 'http://cosy.la-studioweb.com/shop/shop-collections/'
        ),
        'o-portfolio-02' => array(
            'title' 		=> 'Portfolio 02',
            'category'      => 'cat2',
            'preview'		=> $dir_url  . 'portfolio-02.jpg',
            'demo_url'      => 'http://cosy.la-studioweb.com/portfolio-02/'
        ),
        'o-portfolio-detail' => array(
            'title' 		=> 'Portfolio Detail',
            'category'      => 'cat2',
            'preview'		=> $dir_url  . 'portfolio-single.jpg',
            'demo_url'      => 'http://cosy.la-studioweb.com/portfolio/portfolio-name-13/'
        ),
        'o-blog-sb' => array(
            'title' 		=> 'Blog Sidebar',
            'category'      => 'cat2',
            'preview'		=> $dir_url  . 'blog-sb.jpg',
            'demo_url'      => 'http://cosy.la-studioweb.com/blog/?la_preset=blog1'
        ),
        'o-blog-msr' => array(
            'title' 		=> 'Blog Masonry',
            'category'      => 'cat2',
            'preview'		=> $dir_url  . 'blog-msr.jpg',
            'demo_url'      => 'http://cosy.la-studioweb.com/blog/?la_preset=blog5'
        ),
        'o-single-blog1' => array(
            'title' 		=> 'Single Blog 01',
            'category'      => 'cat2',
            'preview'		=> $dir_url  . 'blog-single-01.jpg',
            'demo_url'      => 'http://cosy.la-studioweb.com/nunc-in-quam-in/?la_preset=post1'
        ),
        'o-about-01' => array(
            'title' 		=> 'About Us',
            'category'      => 'cat2',
            'preview'		=> $dir_url  . 'about-us-01.jpg',
            'demo_url'      => 'http://cosy.la-studioweb.com/about/'
        ),
        'o-cms-01' => array(
            'title' 		=> 'Coming Soon',
            'category'      => 'cat2',
            'preview'		=> $dir_url  . 'comingsoon.jpg',
            'demo_url'      => 'http://cosy.la-studioweb.com/coming-soon/'
        ),
    );

    return $demo;
}