<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_cosy_preset_product1(){
    return array(
        array(
            'key' => 'main_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'footer_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'woocommerce_product_page_design',
            'value' => 1
        ),
        array(
            'filter_name' => 'cosy/filter/page_title',
            'value' => '<header><div class="page-title h1">SINGLE PRODUCT 01</div></header>'
        )
    );
}