<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_cosy_preset_post1(){
    return array(
        array(
            'key' => 'layout_single_post',
            'value' => 'col-1c'
        ),
        array(
            'key' => 'single_small_layout',
            'value' => 'on'
        ),
        array(
            'key' => 'blog_thumbnail_size',
            'value' => '370x250'
        ),
        array(
            'filter_name' => 'cosy/filter/page_title',
            'value' => '<header><div class="page-title h1">SINGLE BLOG 01</div></header>'
        )
    );
}