<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_cosy_preset_fashion_04(){
    return array(
        array(
            'key' => 'logo',
            'value' => 877
        ),
        array(
            'key' => 'logo_2x',
            'value' => 878
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 877
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 878
        ),
        array(
            'key' => 'header_layout',
            'value' => 2
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '3col444'
        ),
        array(
            'key' => 'footer_full_width',
            'value' => 'no'
        ),
        array(
            'key' => 'footer_copyright',
            'value' => '<div class="row">
    <div class="col-xs-12 col-sm-6"><div class="small letter-spacing-2 text-uppercase">© 2017 Created by LaStudio</div></div>
    <div class="col-xs-12 col-sm-6 text-right">[la_social_link]</div>
</div>'
        ),
        array(
            'filter_name' => 'cosy/filter/footer_column_1',
            'value' => 'fashion-04-footer-1'
        ),
        array(
            'filter_name' => 'cosy/filter/footer_column_2',
            'value' => 'fashion-03-footer-2'
        ),
        array(
            'filter_name' => 'cosy/filter/footer_column_3',
            'value' => 'fashion-03-footer-3'
        )
    );
}