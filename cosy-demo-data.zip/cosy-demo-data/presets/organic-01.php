<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_cosy_preset_organic_01(){
    return array(
        array(
            'key' => 'logo',
            'value' => 900
        ),
        array(
            'key' => 'logo_2x',
            'value' => 901
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 900
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 901
        ),
        array(
            'key' => 'header_layout',
            'value' => 1
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '4col_cosy2'
        ),
        array(
            'key' => 'footer_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'footer_background',
            'value' => array(
                'color' => '#232324'
            )
        ),
        array(
            'key' => 'footer_heading_color',
            'value' => '#fff'
        ),
        array(
            'key' => 'footer_copyright',
            'value' => '<div class="row"><div class="col-xs-12"><div class="small text-center letter-spacing-2 text-uppercase">© 2017 Created by LaStudio</div></div></div>'
        ),
        array(
            'filter_name' => 'cosy/filter/footer_column_1',
            'value' => 'sport-footer-1'
        ),
        array(
            'filter_name' => 'cosy/filter/footer_column_2',
            'value' => 'organic-footer-2'
        ),
        array(
            'filter_name' => 'cosy/filter/footer_column_3',
            'value' => 'sport-footer-3'
        ),
        array(
            'filter_name' => 'cosy/filter/footer_column_4',
            'value' => 'sport-footer-4'
        )
    );
}