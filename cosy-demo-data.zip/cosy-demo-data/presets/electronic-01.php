<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_cosy_preset_electronic_01(){
    return array(
        array(
            'key' => 'logo',
            'value' => 987
        ),
        array(
            'key' => 'logo_2x',
            'value' => 988
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 987
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 988
        ),
        array(
            'key' => 'header_layout',
            'value' => 4
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'yes'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '3col444'
        ),
        array(
            'key' => 'footer_full_width',
            'value' => 'no'
        ),
        array(
            'key' => 'woocommerce_show_rating_on_catalog',
            'value' => 'yes'
        ),
        array(
            'key' => 'footer_copyright',
            'value' => '<div class="row"><div class="col-xs-12"><div class="small text-center letter-spacing-2 text-uppercase">© 2017 Created by LaStudio</div></div></div>'
        ),
        array(
            'filter_name' => 'cosy/filter/footer_column_1',
            'value' => 'electronic-footer-1'
        ),
        array(
            'filter_name' => 'cosy/filter/footer_column_2',
            'value' => 'sport-footer-3'
        ),
        array(
            'filter_name' => 'cosy/filter/footer_column_3',
            'value' => 'sport-footer-4'
        )
    );
}