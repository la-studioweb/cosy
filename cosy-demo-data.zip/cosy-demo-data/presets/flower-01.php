<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_cosy_preset_flower_01(){
    return array(
        array(
            'key' => 'logo',
            'value' => 909
        ),
        array(
            'key' => 'logo_2x',
            'value' => 910
        ),
        array(
            'key' => 'logo_transparency',
            'value' => 909
        ),
        array(
            'key' => 'logo_transparency_2x',
            'value' => 910
        ),
        array(
            'key' => 'header_layout',
            'value' => 1
        ),
        array(
            'key' => 'header_full_width',
            'value' => 'no'
        ),
        array(
            'key' => 'footer_layout',
            'value' => '3col444'
        ),
        array(
            'key' => 'footer_full_width',
            'value' => 'no'
        ),
        array(
            'filter_name' => 'cosy/filter/footer_column_1',
            'value' => 'flower-footer-1'
        ),
        array(
            'key' => 'body_background',
            'value' => array(
                'image' => 'http://cosy.la-studioweb.com/wp-content/uploads/2017/04/m-8-bg-body.jpg',
                'color' => '#dce8e4'
            )
        ),
        array(
            'key' => 'body_boxed',
            'value' => 'yes'
        ),
        array(
            'key' => 'body_boxed_background',
            'value' => array(
                'color' => '#fff'
            )
        ),
        array (
            'key' => 'primary_color',
            'value' => '#91d4c0',
        ),
        array (
            'key' => 'header_link_hover_color',
            'value' => '#91d4c0',
        ),
        array (
            'key' => 'mm_lv_1_hover_color',
            'value' => '#91d4c0',
        ),
        array (
            'key' => 'header_top_link_hover_color',
            'value' => '#91d4c0',
        ),
        array (
            'key' => 'transparency_header_link_hover_color',
            'value' => '#91d4c0',
        ),
        array (
            'key' => 'transparency_mm_lv_1_hover_color',
            'value' => '#91d4c0',
        ),
        array (
            'key' => 'offcanvas_link_hover_color',
            'value' => '#91d4c0',
        ),
        array (
            'key' => 'mb_lv_1_hover_color',
            'value' => '#91d4c0',
        ),
        array (
            'key' => 'mb_lv_2_hover_color',
            'value' => '#91d4c0',
        ),
        array (
            'key' => 'page_title_bar_link_hover_color',
            'value' => '#91d4c0',
        ),
        array (
            'key' => 'footer_link_hover_color',
            'value' => '#91d4c0',
        ),
        array (
            'key' => 'footer_copyright_link_hover_color',
            'value' => '#91d4c0',
        ),
        array (
            'key' => 'la_custom_css',
            'value' => '.body-boxed .site-header:not(.is-sticky) .site-branding {
    line-height: 120px;
}
.body-boxed .site-header:not(.is-sticky) .header-right{
    padding-top: 40px;
    padding-bottom: 40px;
}
.body-boxed .site-header:not(.is-sticky) .site-main-nav .main-menu > li > a:after{
    bottom: -40px;
}
.body-boxed .site-header:not(.is-sticky) .mega-menu > li > .popup{
    margin-top: 60px;
}
.body-boxed .site-header:not(.is-sticky) .mega-menu > li:hover > .popup{
    margin-top: 40px;
}',
        ),
    );
}